---
title: "Deploy to kind"
description: "Deploy kube-prometheus to Kubernets kind."
lead: "Deploy kube-prometheus to Kubernets kind."
date: 2021-03-08T23:04:32+01:00
draft: false
images: []
menu:
  docs:
    parent: "kube"
weight: 500
toc: true
---

---

Time to explain how!

Your chance of [**contributing**](https://github.com/prometheus-operator/kube-prometheus/blob/main/docs/deploy-kind.md)!
